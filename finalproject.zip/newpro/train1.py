#importing librabries

from __future__ import print_function
import keras
from keras.utils import to_categorical
from keras.datasets import mnist
from keras.layers import Conv2D, MaxPooling2D

from keras import backend as K
batch_size = 128
num_classes = 10
epochs = 12
img_rows, img_cols = 28, 28
#Loading MNIST Dataset

(img_train, label_train), (img_test, label_test) = mnist.load_data()
img_train=img_train.reshape((60000,28,28,1))
#Applyin Min Max Scaling
img_train=img_train.astype('float32')/255
img_test=img_test.reshape((10000,28,28,1))
img_test=img_test.astype('float32')/255

#Converting test and train to Categorical data
label_train_one_hot = to_categorical(label_train)
label_test_one_hot = to_categorical(label_test)

#Applying CNN

from keras import models,layers
model=models.Sequential()
model.add(layers.Conv2D(32,(3,3),activation='relu',input_shape=(28,28,1)))
model.add(layers.MaxPooling2D((2,2)))
model.add(layers.Conv2D(16,(5,5),activation='relu'))
model.add(layers.MaxPooling2D((2,2)))

#Applying ANN on the data recived after CNN
model.add(layers.Flatten())
model.add(layers.Dense(64,activation='relu'))
model.add(layers.Dense(10,activation='softmax'))

#Compiling the data
model.compile(optimizer='rmsprop',loss='categorical_crossentropy',metrics=['accuracy'])
model.fit(img_train,label_train_one_hot,epochs=20,batch_size = 128)
test_loss , test_acc = model.evaluate(img_test, label_test_one_hot)
print(test_acc)

#Storing Model as a json
model_json = model.to_json()
with open("model.json", "w") as json_file:
    json_file.write(model_json)
# serialize weights to HDF5
model.save_weights("model.h5")
print("Saved model to disk")
